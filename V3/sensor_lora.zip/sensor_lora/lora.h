#include <Arduino.h>
#include <lmic.h>
#include <hal/hal.h>
#include <SPI.h>
#include "secrets.h"
#include "mcu_functions.h"
#include "utils.h"

void setup_lora(void);
void loop_lora(void);
